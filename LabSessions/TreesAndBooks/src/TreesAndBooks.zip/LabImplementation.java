/**
 * Class to execute project.
 */
public class LabImplementation {
    public static void main(String[] args) {
        ProcessBook.findPalindromesIn("https://www.gutenberg.org/files/4300/4300-0.txt");
        ProcessBook.reportResults();
    }
}
